function adjustColorsForRedGreenBlindness(data) {
  for (let i = 0; i < data.length; i += 4) {
    let r = data[i];
    let g = data[i + 1];
    let b = data[i + 2];

    // 简单的红绿色盲颜色调整算法
    let newR = r * 0.8;
    let newG = g * 0.8 + r * 0.2;
    let newB = b;

    data[i] = newR;
    data[i + 1] = newG;
    data[i + 2] = newB;
  }
}

function applyColorblindFilter() {
  let style = document.createElement('style');
  style.id = 'colorblindFilter';
  style.innerHTML = `
    img, video {
      filter: contrast(0.8) brightness(1.2) sepia(0.5);
    }
  `;
  document.head.appendChild(style);
}

function removeColorblindFilter() {
  let style = document.getElementById('colorblindFilter');
  if (style) {
    style.remove();
  }
}


document.addEventListener('DOMContentLoaded', () => {
  let images = document.getElementsByTagName('img');
  for (let img of images) {
    img.setAttribute('data-original-src', img.src);
  }
});

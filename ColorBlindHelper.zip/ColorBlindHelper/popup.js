document.getElementById('applyFilter').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      function: applyColorblindFilter,
    });
  });
});

document.getElementById('removeFilter').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      function: removeColorblindFilter,
    });
  });
});

function applyColorblindFilter() {
  let style = document.createElement('style');
  style.id = 'colorblindFilter';
  style.innerHTML = `
    img, video {
      filter: contrast(0.8) brightness(1.2) sepia(0.5);
    }
  `;
  document.head.appendChild(style);
}

function removeColorblindFilter() {
  let style = document.getElementById('colorblindFilter');
  if (style) {
    style.remove();
  }
}
